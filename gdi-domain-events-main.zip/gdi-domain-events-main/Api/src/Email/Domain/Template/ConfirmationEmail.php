<?php

namespace Gdi\Api\Email\Domain\Template;

final readonly class ConfirmationEmail implements EmailTemplate
{
    // Here it should be implemented the confirmation E-mail template
}