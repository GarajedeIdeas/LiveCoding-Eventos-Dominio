<?php

namespace Gdi\Api\Email\Domain\Template;

interface EmailTemplate
{

}