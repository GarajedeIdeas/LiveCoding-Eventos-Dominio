<?php

namespace Gdi\Api\Email\Domain\Template;

final readonly class WelcomeEmail implements EmailTemplate
{
    // Here it should be implemented the welcome E-mail template
}