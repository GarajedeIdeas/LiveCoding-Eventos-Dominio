<?php

namespace Gdi\Api\Film\Domain\ValueObject;

use Gdi\Shared\Domain\ValueObject\Uuid;

final class FilmId extends Uuid
{

}