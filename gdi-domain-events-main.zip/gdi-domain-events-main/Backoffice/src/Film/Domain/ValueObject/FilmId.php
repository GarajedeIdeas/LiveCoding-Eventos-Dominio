<?php

namespace Gdi\Backoffice\Film\Domain\ValueObject;

use Gdi\Shared\Domain\ValueObject\Uuid;

final class FilmId extends Uuid
{

}